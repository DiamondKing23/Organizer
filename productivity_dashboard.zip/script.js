document.addEventListener("DOMContentLoaded", function () {
    loadTasks();
});

function addTask() {
    let input = document.getElementById("taskInput");
    let taskText = input.value.trim();
    if (taskText) {
        let list = document.getElementById("todo-list");
        let li = document.createElement("li");
        li.textContent = taskText;
        li.onclick = () => {
            li.remove();
            saveTasks();
        };
        list.appendChild(li);
        input.value = "";
        saveTasks();
    }
}

// Save tasks to localStorage
function saveTasks() {
    let tasks = [];
    document.querySelectorAll("#todo-list li").forEach(li => {
        tasks.push(li.textContent);
    });
    localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Load tasks from localStorage
function loadTasks() {
    let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
    let list = document.getElementById("todo-list");
    tasks.forEach(taskText => {
        let li = document.createElement("li");
        li.textContent = taskText;
        li.onclick = () => {
            li.remove();
            saveTasks();
        };
        list.appendChild(li);
    });
}
